package ru.microbyte.composite;

public class Square implements Shape{
    public void draw() {
        System.out.println("i'm suare");
    }
}
