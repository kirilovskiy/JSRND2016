package ru.microbyte.composite;

public interface Shape {
    void draw();
}
