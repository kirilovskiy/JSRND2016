package ru.microbyte.adapter;


public class JavaRaster {
    public void drawRasterLine() {
        System.out.println("Draw line");
    }

    public void drawRasterSquare() {
        System.out.println("Draw square");
    }

}
