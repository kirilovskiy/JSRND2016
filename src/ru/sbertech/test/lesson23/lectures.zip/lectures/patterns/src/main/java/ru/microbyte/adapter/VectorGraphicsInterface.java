package ru.microbyte.adapter;

public interface VectorGraphicsInterface {
    void drawLine();
    void drawSquare();
}
