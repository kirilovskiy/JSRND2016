package ru.microbyte.composite;

public class Triangle implements Shape{
    public void draw() {
        System.out.println("i'm triangle");
    }
}
