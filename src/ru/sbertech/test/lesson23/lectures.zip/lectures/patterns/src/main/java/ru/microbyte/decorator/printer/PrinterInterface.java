package ru.microbyte.decorator.printer;


interface PrinterInterface {
    void print(String text);
}
