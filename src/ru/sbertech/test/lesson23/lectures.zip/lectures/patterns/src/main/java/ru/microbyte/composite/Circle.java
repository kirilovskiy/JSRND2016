package ru.microbyte.composite;

public class Circle implements Shape{
    public void draw() {
        System.out.println("i'm circle");
    }
}
