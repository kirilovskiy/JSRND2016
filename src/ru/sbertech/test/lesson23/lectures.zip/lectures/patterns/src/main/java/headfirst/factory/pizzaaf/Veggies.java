package headfirst.factory.pizzaaf;

public interface Veggies {
	public String toString();
}
