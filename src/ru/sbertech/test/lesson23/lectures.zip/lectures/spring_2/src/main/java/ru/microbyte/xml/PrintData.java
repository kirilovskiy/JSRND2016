package ru.microbyte.xml;

public class PrintData {

    String data;

    public PrintData(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
