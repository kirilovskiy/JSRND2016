package ru.microbyte.java;

public interface IPrinter {
    void out(String data);
}
