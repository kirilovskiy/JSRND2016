package ru.microbyte.xml;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


// log
// session
// validation
// profile
// notification
// security
// synchronize
// cache
// transaction
// data transfom
public class TShirtPrintService implements PrintService{

    Logger log = LoggerFactory.getLogger(TShirtPrintService.class);

    public void print(PrintData printData) {
//
//        validator.validate(printData);
//
//        log.info("in method");
//
//        changeMetrics.start();
//
//        StrangeData strangeData = new StrangeData();
//        strangeData.setData(printData.getData());
//
//        try {
//            new TShirtPrinter().StrangePrintMethod(strangeData); // !!!!!!!!!!!
//        } catch (NullPointerException e) {
//            notifyAdministrator.sendMessage("Ой");
//        } catch (RuntimeException e) {
//            log.error("", e);
//            throw e;
//        }
//
//        changeMetrics.stop();
//
//        log.info("in method");
    }
}
