package ru.microbyte.xml;


interface PrintService {
    void print(PrintData printData);
}
