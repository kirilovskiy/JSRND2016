package ru.microbyte.java;

public abstract class RandomNumberHolder {

    abstract RandomNumber getRandomNumber();
}
