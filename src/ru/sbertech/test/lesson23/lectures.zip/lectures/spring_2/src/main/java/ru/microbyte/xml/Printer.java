package ru.microbyte.xml;

public interface Printer {
    void out(PrintData printData);
}
