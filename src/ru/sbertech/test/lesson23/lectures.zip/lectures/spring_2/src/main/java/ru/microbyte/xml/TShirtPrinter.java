package ru.microbyte.xml;

public class TShirtPrinter {
    void StrangePrintMethod(StrangeData anyData) {
        System.out.println(anyData.getData());
    }
}
