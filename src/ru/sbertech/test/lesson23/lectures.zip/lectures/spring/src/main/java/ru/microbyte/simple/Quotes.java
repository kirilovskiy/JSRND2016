package ru.microbyte.simple;

public interface Quotes {
    void sayQuotes();
}
