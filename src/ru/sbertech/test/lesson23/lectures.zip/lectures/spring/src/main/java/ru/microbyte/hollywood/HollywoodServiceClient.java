package ru.microbyte.hollywood;


/**
 * Code for listing 3_8
 */
public class HollywoodServiceClient {

//  public static void main(String[] args) {
//    Injector injector = Guice.createInjector(new AgentFinderModule());
//    HollywoodServiceGuice hollywoodService = injector
//        .getInstance(HollywoodServiceGuice.class);
//    List<Agent> agents = hollywoodService.getFriendlyAgents();
//    // Do stuff with agents.
//  }

}
